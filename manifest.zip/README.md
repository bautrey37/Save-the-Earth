COP4331-Sum13
=============

Project in Processes for Object Oriented Software class this summer 2013.

Team Name:
Earth's Defenders

Team Members:
Brandon Autrey
Matt Dworkin
Stephen Maguire
Thomas J. O'Neill
Jared Wasserman
